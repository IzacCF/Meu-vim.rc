#!/bin/bash
# Script gerador de HTML para imagens
# Autores:
# Leandro <http://www.vivaolinux.com.br/~leandro>
# Izaias <http://www.vivaolinux.com.br/~izaias>


# Requer o pacote "curl" e opcionalmente o pacote "recode"
# O comando "recode" é usado para converter símbolos HTML
# Por exemplo: &gt; em > ou &lt; em < etc.

# Opções de uso:
# get_imagens.sh [tipo] [codigo] [html] [imagem]
# Onde:
#  - [tipo]   - Tipo de conteúdo (artigo ou dica)
#  - [codigo] - Código numérico da contribuição
#  - [html]   - Gerar HTML pequeno (1) ou HTML normal (0)
#  - [imagem] - Nome da imagem a ser buscada

# Checa o tipo de contribuição
if [ "$1" == "artigo" ] ; then
    tipo="artigo"
elif [ "$1" == "dica" ] ; then
    tipo="dica"
else
    echo 1
    exit
fi

# Checa o código numérico
if [[ "$2" =~ ^[0-9]+$ ]] ; then
    codigo=$2
else
    echo 1
    exit
fi

# Checa o tipo de código a ser gerado (grande ou pequeno)
if (($3)) ; then
    html=2
else
    html=""
fi

# Verifica se o comando recode está disponível
if [ -z $(which recode) ] ; then
    isRecode=0
else
    isRecode=1
fi

# Se o nome da imagem estiver vazio, encerra
if [ -z $4 ] ; then
    echo 1
    exit
else
    #Escapa alguns caracteres: []
    imagem=$(echo $4 | sed 's/\[/\\[/g' | sed 's/\]/\\]/g')
fi

# Acessa o endereço do VOL e obtém o código HTML
format=$(curl -s "https://www.vivaolinux.com.br/admin/${tipo}s/tag${html}.php?imagem=${imagem}&cod${tipo}=${codigo}" | grep -a --text "&lt;div class" | sed 's/<br>//g' | sed 's/<!-- br>//g')

if [ -z "$(echo $format | grep -a --text 'img.vivaolinux.com.br')" ] ; then
    echo 1
    exit
fi

# Se o comando recode estiver disponível
# utilizar ele para converter os símbolos HTML
if (($isRecode)) ; then
    result=$(echo "$format" | sed 's/&amp;/\&/g' | recode HTML_4.0)

# Senão, converter manualmente
else
    result=$(echo "$format" |
        sed 's/&amp;/\&/g' |
        sed 's/&amp;/\&/g' |
        sed 's/&lt;/</g'   |
        sed 's/&gt;/>/g'   |
        sed 's/&quot;/"/g')
fi

# Checa se o código HTML está correto
if [[ "$result" =~ width=[0-9]+ ]] ; then
    echo "$result"
else
    echo 1
fi

exit
