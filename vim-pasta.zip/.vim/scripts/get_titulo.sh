#!/bin/bash
# Baseado no script do Fábio
# Modificado por Leandro Nkz <leandronkz@gmail.com>
# Requer o pacote "curl"

for X in `cat /tmp/links`; do

    echo -n '<a href="'
    echo -n $X
    echo -n '">'

    if [ -f `echo $X | grep 'vivaolinux.com.br'` ] ; then
        wget -q $X -O /tmp/title

        if [ `file /tmp/title -b --mime-encoding` != "utf-8" ] ; then
            iconv -f iso-8859-1 -t utf-8 /tmp/title > /tmp/title2
            mv /tmp/title2 /tmp/title
        fi

        TITLE=`grep -i "<title>" /tmp/title | sed 's/.title.//i' | sed 's/..title.//i' | sed 's/|/\&laquo;/' | sed 's///g'`

        if [ -z "$TITLE" ] ; then
            TITLE="$X"
        fi
    else
        curl -s $X -o /tmp/title
        iconv -f iso-8859-1 -t utf-8 /tmp/title > /tmp/title2
        mv /tmp/title2 /tmp/title
        CAT=`echo $X | cut -f4 -d'/'`

        case $CAT in
            "artigo"|"dica")
                TITLE=`grep '<meta itemprop="name" content=' /tmp/title | sed 's/.*content="Linux: //' | sed 's/".*//' | sed 's///g'`
            ;;
            "script")
                TITLE=`grep -i "<title>Linux:" /tmp/title | sed 's/.*<title>Linux: //' | sed 's/<\/title>//' | sed 's///g'`
            ;;
            "screenshot")
                TITLE=`grep '<meta itemprop="name" content=' /tmp/title | sed 's/.*content="Screenshot Linux: //' | sed 's/".*//' | sed 's///g'`
                TITLE+=" [Screenshot]"
            ;;
            "etc")
                TITLE=`grep -i "<title>Linux:" /tmp/title | sed 's/.*<title>Linux: //' | sed 's/<\/title>//' | sed 's///g'`
                TITLE+=" [Conf]"
            ;;
            "topico")
                TITLE=`grep -i "<title>Linux:" /tmp/title | sed 's/.*<title>Linux: //' | sed 's/<\/title>//' | sed 's///g'`
                TITLE+=" [Tópico]"
            ;;
        esac
    fi

    echo -n $TITLE
    echo -n '</a>'
    echo ""
done

rm /tmp/links
rm -f /tmp/title /tmp/title2
