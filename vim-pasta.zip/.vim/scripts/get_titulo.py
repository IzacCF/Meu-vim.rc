#!/usr/bin/env python3

# sudo apt install python3-pip
# pip3 install requests-html

from requests_html import HTMLSession

with open('/tmp/links') as fp:
    for url in fp:
        url = url.strip()
        titulo = HTMLSession().get(url).html.find('title', first=True).text
        print('<a href="%s">%s</a>' %(url, titulo))
